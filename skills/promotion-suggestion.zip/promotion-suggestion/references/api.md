# 增值推广建议 — 字段参考

## 公共响应结构

| 字段 | 类型 | 说明 |
|------|------|------|
| `code` | integer | `0` 成功、`403` 未开放、`1001` 业务错误 |
| `message` | string | 提示信息 |
| `data` | object/null | 业务数据 |
| `status` | string | 成功 `"0"`，失败 `"error"` |

## `data` 完整字段

| 字段 | 类型 | 说明 |
|------|------|------|
| `list` | array | 推广建议展示列表 |
| `oneClickParam` | array | 一键推广请求参数 |
| `totalFee` | string | 预估总费用 |
| `errorReason` | string | 无建议时的提示 |
| `totalConsumeFee` | string | 预估直接消耗费用（置顶） |
| `totalConsumeHouse` | integer | 预估直接消耗房源数（置顶） |
| `totalBudgetFee` | string | 精选与黄金眼每日预算合计 |
| `totalBudgetHouse` | integer | 精选与黄金眼房源数合计 |
| `totalTopFee` / `totalTopHouse` | string / integer | 置顶 |
| `totalChoiceFee` / `totalChoiceHouse` | string / integer | 精选 |
| `totalGoldenEyeFee` / `totalGoldenEyeHouse` | string / integer | 黄金眼 |

## `list[]` 完整字段

| 字段 | 类型 | 说明 |
|------|------|------|
| `houseType` | string | 房源类型 |
| `houseId` | integer | 房源 ID |
| `houseTitle` / `houseImg` / `houseAddress` / `houseDesc` | string | 房源展示信息 |
| `cateType` | string | `esf`、`zf` |
| `promotionType` | integer | `1` 置顶、`2` 精选、`6` 黄金眼 |
| `isSharedChoice` | boolean | 是否共享预算精选 |
| `productType` | string | `zd`、`jx`、`hjy` |
| `site` | integer | `1` 安居客、`2` 58、`3` 双网 |
| `days` | integer | 推荐推广天数 |
| `multi` / `extend` | integer/null | 置顶倍数、是否延长 |
| `budget` | string/null | 每日预算 |
| `recommendReason` / `promotionDesc` / `priceDesc` | string | 文案 |
| `url` | string | 单条去推广地址 |
| `price` | string | 该条预估费用 |
| `prices[]` | array | `{ name, price, unit }` 价格明细 |

## `oneClickParam[]` 完整字段

| 字段 | 类型 | 说明 |
|------|------|------|
| `houseId` | integer | 房源 ID |
| `type` | integer | `1` 置顶、`2` 精选、`6` 黄金眼 |
| `site` | integer | 推广平台 |
| `days` | integer | 推广天数 |
| `multi` | integer/null | 置顶倍数 |
| `budget` | string/null | 精选/黄金眼每日预算 |
| `consume` | string/null | 兼容字段，一键推广不使用 |
| `bid` | string/null | 黄金眼微聊/VR 带看出价 |
| `ajkCoupon` / `wubaCoupon` | string | 优惠券编码 |
| `extend` | integer/null | 延长置顶，未传按 `0` |
