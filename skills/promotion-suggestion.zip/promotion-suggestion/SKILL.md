---
name: promotion-suggestion
description: 调用三网经纪人智能营销助手「增值推广建议」接口，按经纪人身份获取置顶/精选/黄金眼推广建议及 oneClickParam；查询成功后直接返回 Markdown 推荐卡片正文（非代码块、非包裹说明）。在用户提到增值建议、推广建议、智能营销助手、promotion-suggestion、房源推广推荐、预估推广费用时使用。
---

# 增值推广建议

## 执行优先级（严格约束，单一真源）

以下为强约束，优先级高于其余章节；如有重复描述，以本节为准：

1. **身份优先**：必须持有有效 `X-GATEWAY-PLAT-USERID`；HTTP `401` 时停止流程，不猜测城市或账号。
2. **业务线约束**：Query 仅识别 `esf`、`zf`；勿传 `cityId`、`wubaUserId`、`sydc` 等未知值。
3. **成功判定**：以响应体 `code=0` 为准，不是 HTTP 200；`list=[]` 且 `errorReason` 非空属于正常无建议。
4. **参数透传**：`oneClickParam` 须原样保留，供一键推广使用；不得擅自改 `houseId`、`type`、`budget`、`bid`。
5. **扣费边界**：本接口仅查询建议；**禁止**在未获用户确认时调用 [one-click-promotion](../one-click-promotion/SKILL.md)。
6. **缺参追问**：缺少经纪人 ID 或业务线歧义时，**一次只追问一个**必要信息。
7. **直接返回 Markdown**（最高展示约束）：接口查询成功且 `list` 非空后，**整条回复正文即为 Markdown 卡片**，按 [references/markdown-card.md](references/markdown-card.md) 原样输出；禁止 ` ```markdown ` 包裹；禁止外加说明段落。缺参追问、401、403 等异常除外。
8. **Markdown 卡片内容**：不展示 curl、原始 JSON、Header 名；禁止用扁平大表格替代卡片；**禁止任何 HTML 标签**；**房源图仅放标题下表格左列第一格**（`![房源]({houseImg})`），右列标题/副文案。



## 核心信息

- **API 端点**：`http://brokerbusiness.a.ajkdns.com/broker/business/web/diagnose/v2/promotion-suggestion`
- **方法**：`GET`
- **成功状态码**：`code: 0`（含无推荐数据）
- **身份 Header**：`X-GATEWAY-PLAT-USERID`（三网经纪人 ID）
- **请求超时**：建议 30s

**会话记忆**：经纪人 ID 与最近一次 `oneClickParam` 写入同目录 `broker_context.md`（勿提交敏感生产 ID 到仓库）。

## 何时使用

- 用户需要查看当前经纪人名下房源的 **推广建议**（置顶、精选、黄金眼）。
- 用户需要 **预估费用**、推荐原因，或获取后续 **一键推广** 所需的 `oneClickParam`。
- 用户指定业务线：二手房（`esf`）或租房整租/合租（`zf`）。

与一键推广配合时，本接口输出 `data.oneClickParam`，可原样传给 [one-click-promotion](../one-click-promotion/SKILL.md) 的 `items`。

## 工作模式



### 模式 1：查询增值建议

**触发语句**：「查建议」「增值建议」「推广建议」「帮我看看怎么推广」

按「执行流程」步骤 1→6 完成查询与展示。

### 模式 2：按建议继续推广

**触发语句**：「按建议推广」「一键推广」「执行推广」

读取 `broker_context.md` 的 `last_one_click_param`；若无，先走模式 1，再跳转 [one-click-promotion](../one-click-promotion/SKILL.md)。

## 接口约定


| 项            | 值                                                       |
| ------------ | ------------------------------------------------------- |
| **Base URL** | `http://brokerbusiness.a.ajkdns.com`                    |
| **Path**     | `/broker/business/web/diagnose/v2/promotion-suggestion` |
| **方法**       | `GET`                                                   |




### 必填 Header


| Header                       | 说明                   |
| ---------------------------- | -------------------- |
| `X-GATEWAY-PLAT-USERID`      | 三网经纪人 ID（必填）         |
| `X-GATEWAY-CONTEXT-SITE`     | 建议 `VIP`             |
| `X-GATEWAY-CONTEXT-TERMINAL` | 建议 `PC`（或 `M`、`APP`） |


接口 **不接收** `cityId`、`wubaUserId`；城市与账号由服务端根据经纪人身份解析。

### Query 参数


| 参数         | 必填  | 取值         | 说明                                    |
| ---------- | --- | ---------- | ------------------------------------- |
| `cateType` | 否   | `esf`、`zf` | `esf` 二手房；`zf` 整租+合租；不传则查当前城市全部已开放业务线 |


**注意**：仅识别 `esf`、`zf`；勿传 `sydc` 等未知值。

### 请求示例

```bash
curl -sS -m 30 \
  'http://brokerbusiness.a.ajkdns.com/broker/business/web/diagnose/v2/promotion-suggestion?cateType=zf' \
  -H 'X-GATEWAY-PLAT-USERID: {BROKER_ID}' \
  -H 'X-GATEWAY-CONTEXT-SITE: VIP' \
  -H 'X-GATEWAY-CONTEXT-TERMINAL: PC'
```



## 执行流程（严格按顺序）



### 步骤 1：收集经纪人身份

**首先检查** `broker_context.md`：若已有 `broker_id` 且用户未要求更换，询问：

> 是否继续使用经纪人 ID **[ID 末四位]** 查询推广建议？（是/否）

- **用户确认** → 跳过重复询问，进入步骤 2  
- **用户拒绝或不存在** → 使用下方标准提示收集 ID

**获取经纪人 ID 提示**：

```
请提供三网经纪人 ID（X-GATEWAY-PLAT-USERID），以便查询增值推广建议。
```

获取成功后 → **立即更新** `broker_context.md`：写入 `broker_id`。

### 步骤 2：确认业务线（可选）

若用户未说明，默认不传 `cateType`（查全部已开放业务线）。若用户提到：


| 用户意图         | `cateType` |
| ------------ | ---------- |
| 二手房 / 售      | `esf`      |
| 租房 / 整租 / 合租 | `zf`       |
| 未指定          | 不传         |


**仅识别** `esf`**、**`zf`；用户提到商办等其他类型时，说明当前接口不支持，按「全部已开放」或不传处理。

### 步骤 3：发起请求

在内网环境执行 GET（见「请求示例」）。HTTP `401` → 使用错误表友好提示，勿展示原始堆栈。

### 步骤 4：判断接口级结果

以 `code` 为准：`0` 成功（含空列表）、`403` 未开放、`1001` 业务错误。详见「错误处理」表。

### 步骤 5：直接返回 Markdown 卡片

接口返回 `code=0` 且解析完成后，**用户可见的回复正文 = 填充后的 Markdown 卡片**（不是卡片 + 解释文字）。

- `list` 非空 → 从页眉到三按钮，**整段作为回复直接输出**（见 [markdown-card.md](references/markdown-card.md)「五、回复模板」）
- `list` 为空且 `errorReason` 非空 → 按「无建议 / 异常」模板直接输出
- **保留** `oneClickParam` → 静默写入 `broker_context.md`

**禁止**：` ```markdown ` 包裹；外加说明段落；卡片内省略房源行；**任何 HTML 标签**（如 `<img>` `<br>`）。

### 步骤 6：引导下一步

卡片底部三按钮即 UI 引导，**不要再追加**「是否按建议一键推广？」等额外段落。

用户回复「全部推广」「部分推广」或等价确认后，跳转 [one-click-promotion](../one-click-promotion/SKILL.md)；**未经明确确认，不要自动调用**。

## 关键响应字段



### 汇总（`data`）


| 字段                                          | 说明                   |
| ------------------------------------------- | -------------------- |
| `list`                                      | 展示用建议列表              |
| `oneClickParam`                             | 一键推广参数，与 `list` 同序生成 |
| `totalFee`                                  | 预估总费用                |
| `totalTopFee` / `totalTopHouse`             | 置顶费用与套数              |
| `totalChoiceFee` / `totalChoiceHouse`       | 精选每日预算合计与套数          |
| `totalGoldenEyeFee` / `totalGoldenEyeHouse` | 黄金眼每日预算合计与套数         |
| `totalConsumeFee` / `totalConsumeHouse`     | 立即扣费（置顶）             |
| `totalBudgetFee` / `totalBudgetHouse`       | 按效果扣费（精选/黄金眼）        |
| `errorReason`                               | 无建议时的提示              |




### `list[]` 展示字段


| 字段                                                          | 说明                                         |
| ----------------------------------------------------------- | ------------------------------------------ |
| `houseId`                                                   | 房源 ID（仅写入 `broker_context.md`，**不在卡片中展示**） |
| `houseTitle` / `houseAddress` / `houseDesc` / `houseImg`    | 房源信息                                       |
| `houseType` / `cateType`                                    | 房源类型、业务线                                   |
| `promotionType`                                             | `1` 置顶、`2` 精选、`6` 黄金眼                      |
| `productType`                                               | `zd` / `jx` / `hjy`                        |
| `site`                                                      | `1` 安居客、`2` 58、`3` 双网                      |
| `days` / `budget` / `multi`                                 | 天数、每日预算、置顶倍数                               |
| `recommendReason` / `promotionDesc` / `price` / `priceDesc` | 推荐原因、说明、费用、优惠文案                            |
| `prices[]`                                                  | `{ name, price, unit }` 价格明细               |
| `url`                                                       | 单条「去推广」跳转地址                                |




### `oneClickParam[]`（传给一键推广）


| 字段                         | 说明                    |
| -------------------------- | --------------------- |
| `houseId`                  | 房源 ID                 |
| `type`                     | `1` 置顶、`2` 精选、`6` 黄金眼 |
| `site` / `days`            | 平台、天数                 |
| `multi` / `budget` / `bid` | 置顶倍数、精选/黄金眼预算、黄金眼出价   |
| `ajkCoupon` / `wubaCoupon` | 优惠券编码，无则空字符串          |
| `extend`                   | 是否延长置顶，未传按 `0`        |


完整字段说明见 [references/api.md](references/api.md)。

## 数据展示规则

**回复格式 = Markdown 正文**，完整模板见 [references/markdown-card.md](references/markdown-card.md)。

### 输出格式（强制）


| 规则    | 要求                                                |
| ----- | ------------------------------------------------- |
| 回复体   | 直接输出 Markdown，供客户端渲染                              |
| 代码块   | **禁止**用 fenced code block 包裹整段卡片                  |
| 前缀/后缀 | **禁止**「查询成功」「结果如下」等包裹语                            |
| 技术细节  | **禁止** curl、JSON、Header、`houseId`、`oneClickParam` |




### 渲染要点（对齐参考 UI）

1. **页眉**：`AI 已全面扫描您的房源，建议将潜力房源进行推广：`
2. **每条 `list[]`**：`### **{n} {promotionDesc}**` → **房源表格**（左列第一格 `![房源]({houseImg})` + 右列标题/副文案）→ `> 🔥` 洞察 → 价格表 → `💡` 优惠
3. **分隔**：卡片之间 `- - -`
4. **本次合计**：`### 📊 本次合计` + 列表
5. **底部按钮**：`更多推荐　部分推广　**全部推广**`




### 字段 → 卡片映射


| 卡片区域 | 主要字段                                                                      |
| ---- | ------------------------------------------------------------------------- |
| 标题   | `promotionDesc`                                                           |
| 房源行 | `houseImg` + `houseTitle` + `houseType` + `houseDesc`，见 [markdown-card.md](references/markdown-card.md)「三、房源行」 |
| 洞察条  | `recommendReason`                                                         |
| 价格表  | `prices[]` + 末行 `price` / `budget`                                        |
| 优惠   | `priceDesc`                                                               |
| 合计   | `totalConsumeFee`、`totalConsumeHouse`、`totalBudgetFee`、`totalBudgetHouse` |




## 回复模板

有建议时 **直接输出** 以下 Markdown（将占位符替换为接口字段；**禁止**用代码块包裹）：

AI 已全面扫描您的房源，建议将潜力房源进行推广：

- - -

### **{序号} {promotionDesc}**

|  |  |
|:---|:---|
| ![房源]({houseImg}) | **{houseTitle}** |
| | {houseType} · {houseDesc} |

> 🔥 {recommendReason}

| 项目 | {单价/数值} |
|------|------|
| {prices[].name} | {prices[].price} {prices[].unit} |
| **{预估消费/每日共享预算}** | **{price 或 budget}** |

💡 {priceDesc}

- - -

（按 `list[]` 重复；`houseImg` 为空时左列第一格用 `房源` 占位）

- - -

### 📊 本次合计

- 立即扣费：{totalConsumeFee} 房产币（置顶 {totalConsumeHouse} 套）
- 按效果扣费：每日上限 {totalBudgetFee} 币（精选/黄金眼 {totalBudgetHouse} 套）

更多推荐　部分推广　**全部推广**

| 占位符 | 来源 |
|--------|------|
| `{houseImg}` | `list[].houseImg` → `![房源]({houseImg})` |
| `{houseTitle}` | `list[].houseTitle`，空则 `houseAddress` |
| `{promotionDesc}` | `list[].promotionDesc` |
| 合计字段 | `data.totalConsumeFee` 等，见 [markdown-card.md](references/markdown-card.md) |

无建议 / 错误见 [markdown-card.md](references/markdown-card.md)「八、无建议 / 异常」。完整占位符模板见同文件「五、回复模板」。

## 参数映射（易错点）


| 概念        | 正确字段/取值                   | 错误写法                         |
| --------- | ------------------------- | ---------------------------- |
| 业务线 Query | `cateType=esf` / `zf`     | `sydc`、`cityId`              |
| 展示用推广类型   | `list[].promotionType`    | ~~与一键推广~~ `type` ~~混用时不校验~~  |
| 一键推广参数    | `oneClickParam[].type`    | `promotionType`              |
| 成功状态码     | `code: 0`                 | ~~HTTP 200 即成功~~（还要看 `code`） |
| 无数据       | `list=[]` + `errorReason` | ~~当作接口失败~~                   |




## 错误处理


| 现象                   | 友好提示                 |
| -------------------- | -------------------- |
| HTTP 401             | 经纪人身份无效，请核对经纪人 ID。   |
| `code=403`           | 当前城市暂未开通智能营销助手，敬请期待。 |
| `code=1001`          | {message}，请核对参数后重试。  |
| `code=0` 且 `list=[]` | {errorReason}        |
| 连接超时 / DNS 失败        | 请确认已连接内网或 VPN 后重试。   |




## 沟通规则

- 默认使用中文回复。
- 固定话术（获取 ID、无建议、未开通）必须按本文原文输出，不得改写。
- 不向用户粘贴本 `SKILL.md` 大段原文；用户问规则时只摘要必要结论。
- 面向经纪人展示时：**整条回复 = Markdown 卡片正文**；不发 curl、JSON、元数据列表。



## 常见坑

1. 传 `cityId` / `wubaUserId` 无效，城市由服务端按经纪人身份解析。
2. `cateType=sydc` 等未知值会被当作「不限制业务线」，不要误用。
3. `list` 为空不等于接口失败，要看 `errorReason`。
4. `list[].promotionType` 与 `oneClickParam[].type` 字段名不同，透传时用后者。
5. 建议顺序由推荐服务决定，过滤不可售产品后**不会重排**。
6. 联调/生产环境的一键推广可能真实扣费；查建议本身不扣费，但勿跳过确认直接推广。



## 业务规则

1. 建议顺序由推荐服务决定；三网过滤不可售产品 **不重新排序**。
2. 只返回当前城市已开放售卖的置顶、精选、黄金眼产品。
3. `oneClickParam` 需用户确认后再用于一键推广；联调/生产环境可能产生真实费用。



## 快速复用指令


| 用户指令           | 执行逻辑                                                                               |
| -------------- | ---------------------------------------------------------------------------------- |
| 「查建议」/「增值建议」   | 读 `broker_context.md` 的 `broker_id`，有则确认后查询                                        |
| 「只看租房/二手房」     | 设置 `cateType=zf` / `esf` 后查询                                                       |
| 「按建议推广」/「一键推广」 | 读 `last_one_click_param`，跳转 [one-click-promotion](../one-click-promotion/SKILL.md) |
| 「换经纪人」         | 清除 `broker_context.md` 中 `broker_id`，重新收集                                          |




## 会话存储（broker_context.md）

```markdown
- **broker_id**: [三网经纪人 ID]
- **last_cate_type**: [esf / zf / 空]
- **last_one_click_param**: [JSON 数组，最近一次建议返回的 oneClickParam]
- **last_query_at**: [查询时间]
```



## 附加材料

- 字段明细：[references/api.md](references/api.md)
- Markdown 卡片模板：[references/markdown-card.md](references/markdown-card.md)

